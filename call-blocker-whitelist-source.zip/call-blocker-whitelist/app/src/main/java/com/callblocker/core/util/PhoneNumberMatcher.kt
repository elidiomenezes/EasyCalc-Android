package com.callblocker.core.util

/** Phone-number comparison used by the whitelist. */
object PhoneNumberMatcher {
    fun normalize(value: String): String {
        val digits = value.filter(Char::isDigit)
        if (digits.isEmpty()) return ""

        // Common international prefixes. Keeping this deliberately conservative
        // avoids stripping a valid local area code.
        return when {
            digits.startsWith("0055") && digits.length in 14..15 -> digits.drop(4)
            digits.startsWith("55") && digits.length in 12..13 -> digits.drop(2)
            digits.startsWith("0052") && digits.length == 14 -> digits.drop(4)
            digits.startsWith("52") && digits.length == 12 -> digits.drop(2)
            digits.startsWith("001") && digits.length == 14 -> digits.drop(3)
            digits.startsWith("1") && digits.length == 11 -> digits.drop(1)
            else -> digits
        }
    }

    fun matches(incoming: String, stored: String, isPrefix: Boolean): Boolean {
        val normalizedIncoming = normalize(incoming)
        val normalizedStored = normalize(stored)
        if (normalizedIncoming.isEmpty() || normalizedStored.isEmpty()) return false
        return if (isPrefix) {
            normalizedIncoming.startsWith(normalizedStored)
        } else {
            normalizedIncoming == normalizedStored
        }
    }
}
