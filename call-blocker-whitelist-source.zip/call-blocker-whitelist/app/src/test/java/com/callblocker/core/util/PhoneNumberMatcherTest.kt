package com.callblocker.core.util

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneNumberMatcherTest {
    @Test
    fun `matches Brazilian number with or without country code`() {
        assertTrue(PhoneNumberMatcher.matches("+55 (13) 99999-1234", "13999991234", false))
    }

    @Test
    fun `does not allow a different number`() {
        assertFalse(PhoneNumberMatcher.matches("+55 13 99999-1234", "13999995678", false))
    }

    @Test
    fun `allows configured prefix only`() {
        assertTrue(PhoneNumberMatcher.matches("+55 13 99999-1234", "139", true))
        assertFalse(PhoneNumberMatcher.matches("+55 11 99999-1234", "139", true))
    }
}
