package com.callblocker.core.util

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneNumberMatcherTest {
    @Test
    fun `matches Brazilian number with or without country code`() {
        assertTrue(PhoneNumberMatcher.matches("+55 (13) 99999-1234", "13999991234", false))
    }

    @Test
    fun `does not allow a different number`() {
        assertFalse(PhoneNumberMatcher.matches("+55 13 99999-1234", "13999995678", false))
    }

    @Test
    fun `allows configured prefix only`() {
        assertTrue(PhoneNumberMatcher.matches("+55 13 99999-1234", "139", true))
        assertFalse(PhoneNumberMatcher.matches("+55 11 99999-1234", "139", true))
    }

    @Test
    fun `accepts international plus and double zero formats`() {
        assertTrue(PhoneNumberMatcher.matches("+351 912 345 678", "00351 912 345 678", false))
        assertTrue(PhoneNumberMatcher.matches("+1 (202) 555-0198", "+12025550198", false))
    }
}
