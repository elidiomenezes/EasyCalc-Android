#include "mock_authorizer.hpp"
#include <initializer_list>
#include <string_view>

namespace payment_gateway {
namespace {
std::string trim(std::string value) {
    while (!value.empty() && value.back() == ' ') value.pop_back();
    return value;
}
}
std::optional<ParsedMessage> MockAuthorizer::respond(const ParsedMessage& request,
                                                     Database* database) {
    std::string response_mti;
    if (request.mti == "0100") response_mti = "0110";
    else if (request.mti == "0200") response_mti = "0210";
    else if (request.mti == "0220") response_mti = "0230";
    else if (request.mti == "0420") response_mti = "0430";
    else return std::nullopt;

    std::string code = "96"; // Cannot approve if merchant registry is unavailable.
    if (database) {
        if (!request.present[42]) code = "03";
        else {
            auto statement = database->prepare(
                "SELECT enabled FROM merchants WHERE merchant_id=:id LIMIT 1");
            const std::string merchant = trim(request.fields[42]);
            statement.bind(":id", std::string_view(merchant));
            code = statement.step() && statement.column_int64(0) == 1 ? "00" : "03";
        }
    }

    ParsedMessage reply = request;
    reply.mti = response_mti;
    // These fields cannot be generated faithfully without cryptographic material.
    for (unsigned de : {52U, 53U, 55U, 64U, 128U}) {
        reply.present[de] = false;
        reply.fields[de].clear();
    }
    reply.present[39] = true;
    reply.fields[39] = code;
    return reply;
}
}
