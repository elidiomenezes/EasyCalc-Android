#!/usr/bin/env python3
"""Integration test: mock authorizer response and Day 4 persistence."""
import os
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]


def iso_request(merchant: str, stan: str, rrn: str) -> bytes:
    fields = {3: "000000", 4: "000000001000", 11: stan, 13: "1119",
              37: rrn, 42: merchant.ljust(15), 49: "566"}
    bitmap = 0
    for de in fields:
        bitmap |= 1 << (64 - de)
    return ("0100" + f"{bitmap:016X}" + "".join(fields[k] for k in sorted(fields))).encode()


def exchange(port: int, payload: bytes, fragmented: bool = False) -> bytes:
    frame = len(payload).to_bytes(2, "big") + payload
    with socket.create_connection(("127.0.0.1", port), timeout=3) as conn:
        if fragmented:
            conn.sendall(frame[:7]); conn.sendall(frame[7:])
        else:
            conn.sendall(frame)
        length = int.from_bytes(recv_exact(conn, 2), "big")
        return recv_exact(conn, length)


def recv_exact(sock, count: int) -> bytes:
    buffer = b""
    while len(buffer) < count:
        part = sock.recv(count - len(buffer))
        if not part:
            raise AssertionError("connection closed before full response")
        buffer += part
    return buffer


def main(binary: str) -> None:
    with tempfile.TemporaryDirectory() as folder:
        db_path = str(Path(folder) / "transactions.sqlite")
        subprocess.run([sys.executable, str(PROJECT / "tools/init_database.py"),
                        "--db", db_path], check=True, stdout=subprocess.DEVNULL)
        with sqlite3.connect(db_path) as db:
            db.execute("INSERT INTO merchants(merchant_id,enabled) VALUES (?,?)",
                       ("MERCHANT0000001", 1))
        with socket.socket() as listener:
            listener.bind(("127.0.0.1", 0))
            port = listener.getsockname()[1]
        env = dict(os.environ, ISO8583_DB_PATH=db_path, ISO8583_MOCK_MODE="1")
        server = subprocess.Popen([binary, f"127.0.0.1:{port}", "127.0.0.1:1"],
                                  env=env, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try:
                    with socket.create_connection(("127.0.0.1", port), timeout=.1):
                        break
                except OSError:
                    if server.poll() is not None:
                        raise AssertionError("gateway exited before listening")
                    time.sleep(.02)
            else:
                raise AssertionError("gateway did not start")
            approved = exchange(port, iso_request("MERCHANT0000001", "123456", "123456789012"), True)
            declined = exchange(port, iso_request("UNKNOWN0000001", "123457", "123456789013"))
            assert approved.startswith(b"0110") and approved[60:62] == b"00", approved
            assert declined.startswith(b"0110") and declined[60:62] == b"03", declined
            for _ in range(100):
                with sqlite3.connect(db_path) as db:
                    rows = db.execute("SELECT stan,status,outcome_code FROM transactions ORDER BY stan").fetchall()
                if len(rows) == 2 and all(row[1] != "PENDING" for row in rows):
                    break
                time.sleep(.02)
            assert rows == [("123456", "APPROVED", "00"), ("123457", "DECLINED", "03")], rows
        finally:
            server.terminate()
            try: server.wait(timeout=3)
            except subprocess.TimeoutExpired: server.kill(); server.wait(timeout=3)


if __name__ == "__main__":
    main(sys.argv[1])
