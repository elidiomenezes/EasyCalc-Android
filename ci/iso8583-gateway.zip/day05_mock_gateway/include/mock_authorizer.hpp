#pragma once
#include "iso8583_parser.hpp"
#include "database.hpp"
#include <optional>

namespace payment_gateway {
// Classroom-only authorizer: checks merchant registration; no PIN/MAC processing.
class MockAuthorizer {
public:
    static std::optional<ParsedMessage> respond(const ParsedMessage& request,
                                                Database* database);
};
}
