# Week 10, Day 5 — Local mock authorizer

This project starts from the **completed instructor reference for Day 4**.
No Day 4 student TODO implementation is used.

## Build

Requires C++17, CMake 3.16+, Boost.Asio headers, SQLite3 development
headers/library, and pthreads.

```sh
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

## Local mock mode

```sh
python3 tools/init_database.py --db transactions.sqlite
python3 -c 'import sqlite3; c=sqlite3.connect("transactions.sqlite"); c.execute("INSERT OR REPLACE INTO merchants(merchant_id,enabled) VALUES (?,?)", ("MERCHANT0000001", 1)); c.commit()'
ISO8583_DB_PATH=transactions.sqlite ISO8583_MOCK_MODE=1 \
    ./build/gateway 127.0.0.1:8583 127.0.0.1:8584
```

The second endpoint is ignored in mock mode and retained for CLI compatibility.
Without `ISO8583_MOCK_MODE=1`, the existing Day 4 transparent proxy is unchanged.

- Incoming messages use the existing 2-byte network-order TCP frame length.
- Complete ISO payloads are parsed using the Day 4 field table.
- `0100`, `0200`, `0220`, `0420` produce `0110`, `0210`, `0230`, `0430`.
- Registered and enabled DE42 merchant → DE39 `00`.
- Missing, unknown, or disabled merchant → DE39 `03`.
- No database configured → DE39 `96`.
- Financial requests are inserted `PENDING` and responses update them after
  a successful socket write, using STAN + RRN + transaction date.
- Other MTIs, including `0800`, do not generate an invented response.
- Malformed payloads are logged without sensitive contents and skipped.
- Sensitive security fields DE52/53/55/64/128 are not echoed into mock replies:
  this is **not** a production NIBSS authorizer, and cannot generate a valid MAC.

Do not use real payment-card data or production authorizations with this mock.
