# ISO 8583 - Week 10, Day 4 - Complete course pack

**Student materials:** `student/` (distribute this directory only).
**Instructor materials:** `instructor/` (keep private).

- `student/Week_10_Day_04_Student_Worksheet.pdf`: assignment, 5 general SQL/database questions and SQLite C API function reference.
- `student/tools/init_database.py`: reproducible SQLite schema initialization.
- `student/include/database.hpp`, `student/src/database.cpp`: RAII wrapper skeleton (TODOs intentionally unimplemented).
- `student/tests/public/test_persistence.py`: public real-TCP and real-SQLite acceptance tests.
- `instructor/tests/*`: private C++ RAII and black-box tests.
- `instructor/grading/grade_day04.py`: automated 75-point practical grading.
- `instructor/answer_key.pdf`: theory answers, expected logic and grading rubric.
- `instructor/reference/`: working instructor solution used to check the tests.

Requirements: Linux, C++17, CMake >= 3.16, Boost headers, SQLite3 development library, Python3 standard library.

See `student/DAY04_START_HERE.md` and `instructor/INSTRUCTOR_NOTES.md`.
