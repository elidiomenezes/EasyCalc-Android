# ISO 8583 - Week 10 Day 4 - Student starter

This is the **complete Day 3 TCP gateway and 57-DE NIBSS parser**, extended with an
**unfinished Day 4 SQLite RAII wrapper**. You must implement the wrapper and use it
to persist financial operations. The TCP gateway remains a transparent proxy;
it must not fabricate responses, apply merchant authorization rules, or change
forwarded data. See `DAY04_START_HERE.md` and the PDF worksheet.

## What's provided

- Fully working `gateway`, `session`, `logger`, `iso8583_parser` modules
- `include/database.hpp`, `src/database.cpp` with method bodies marked TODO
- `schema.sql` plus `tools/init_database.py` to provision a test database
- Public TCP and persistence acceptance suites
- Worksheet with general SQL questions and an SQLite C API quick reference

## Start

```sh
cmake -S . -B build -DBUILD_TESTING=ON
cmake --build build -j2
ctest --test-dir build --output-on-failure
python3 tools/init_database.py --db /tmp/day04.sqlite --reset
ISO8583_DB_PATH=/tmp/day04.sqlite ./build/gateway 127.0.0.1:8500 127.0.0.1:8501
```

Run the existing gateway regression:

```sh
python3 tests/test_gateway_integration.py --gateway ./build/gateway
```

Run the **Day 4** acceptance suite once you have implemented persistence:

```sh
python3 tests/public/test_persistence.py --gateway ./build/gateway
```

**Expected starter condition:** build and Day 3 tests pass; the Day 4 tests **fail**
until the SQLite wrapper and gateway persistence integration are implemented.

## Operating constraints

Each worker must use a separate SQLite connection to the same database file
selected via `ISO8583_DB_PATH`. Keep binding placeholders named (`:stan`, `:rrn`,
`:day`); positional bind arguments must use per-statement constants, not magic
numeric literals. Use the schema and correlation contract specified in the PDF.

All testing uses synthetic data. Never persist raw ISO messages or full PAN,
Track 2, PIN blocks or DE55 contents.
