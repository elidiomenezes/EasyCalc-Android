# Week 10 / Day 4 — Transaction persistence

## What you have

- Working C++17 Day 3 gateway/parser and TCP forwarding
- `include/database.hpp` and `src/database.cpp`: incomplete RAII SQLite wrapper **to implement**
- `schema.sql`, plus `tools/init_database.py` (database provisioning, not a solution)
- `tests/test_parser.cpp`, `tests/test_gateway_integration.py`: Day 3 regression checks
- `tests/public/test_persistence.py`: executable Day 4 black-box acceptance tests
- `Week_10_Day_04_Student_Worksheet.pdf`: required behavior and SQLite API appendix

## Database path contract (required for automatic tests)

The gateway retains its **two existing command-line arguments**:

```sh
./build/gateway 127.0.0.1:8500 127.0.0.1:8501
```

It must read `ISO8583_DB_PATH` from its environment and use the specified SQLite file.
Do not add a mandatory third command-line argument. Each worker owns a SQLite
connection to the **same** database file, never a database per connection.

A test creates the database before launching the gateway:

```sh
python3 tools/init_database.py --db /tmp/day04-transactions.sqlite --reset
```

`--reset` destroys that test file; never use it on real data. Without `--reset`,
initialization is idempotent and retains existing transactions.

## Data mapping and correlation

- MTIs: request `0100`, `0200`, `0220`, `0420` and responses `0110`, `0210`, `0230`, `0430`.
- Operation values: `AUTHORIZATION`, `FINANCIAL`, `ADVICE`, `REVERSAL`, respectively.
- Financial attempts begin with `status='PENDING'` and nullable `outcome_code`/`completed_at`.
- `DE39='00'` means `APPROVED`; any other received DE39 means `DECLINED`.
- Request and response correlate by STAN (DE11), RRN (DE37) **and transaction_date**.
- Use DE13 (MMDD) as the transaction's calendar day, resolving the year from the current UTC year; handle the year boundary rather than assuming every DE13 is in the current year.
- Store `transaction_date` as `YYYY-MM-DD`; `created_at` and `completed_at` as UTC ISO-8601 timestamps.
- DE4 is integer minor currency units (`amount_minor`), DE49 is the numeric currency code, DE42 is `merchant_ref` (trim fixed-width right spaces).
- `cardholder_ref` may be NULL. **Do not store full PAN, Track 2, PIN block, DE55, or raw wire**; deriving a stable cardholder reference is optional, not required for grading.
- Duplicate attempts and duplicate responses must not generate extra rows or overwrite completed outcomes.
- An advice is a financial operation; a reversal is a **separate** operation.
- Network traffic (`0800/0810`, including the malformed sign-on heartbeat) must not create a transaction.
- An invalid ISO payload must still be transparently forwarded but must not produce fabricated financial records.
- If SQLite fails or is locked beyond the bounded timeout, forward the unchanged TCP bytes anyway; log safely.

The gateway is not an authorizer in Day 4; **never invent or send local ISO8583 responses**.

## Build & tests

```sh
cmake -S . -B build -DBUILD_TESTING=ON
cmake --build build -j2
ctest --test-dir build --output-on-failure
python3 tests/test_gateway_integration.py --gateway ./build/gateway
python3 tests/public/test_persistence.py --gateway ./build/gateway
```

The first two suites must pass with the untouched starter. **Persistence tests
are expected to fail until you implement the assignment.**

## Binding parameters

Use named parameters, e.g. `:stan`, `:rrn`, `:day`, not magic positional `1`, `2`, `3` literals. If you must use positional parameters, use statement-specific named `static constexpr int` constants. SQLite column indices are zero-based but bind positions are one-based.

## Submission

Commit completed project and five written SQL/database answers in a Git repository; provide a clone URL. Instructor tests are kept outside this starter tree.
