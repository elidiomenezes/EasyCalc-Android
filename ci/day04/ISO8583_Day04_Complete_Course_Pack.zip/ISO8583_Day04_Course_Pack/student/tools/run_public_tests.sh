#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
cmake -S . -B build -DBUILD_TESTING=ON
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
python3 tests/test_gateway_integration.py --gateway ./build/gateway
python3 tests/public/test_persistence.py --gateway ./build/gateway
