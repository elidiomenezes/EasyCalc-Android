#!/usr/bin/env python3
"""Instructor-only black-box Day 4 integration tests. Do not distribute to students.

No production SQL code is imported. Tests require only the provided gateway executable,
Python standard library, and the student-visible wire fixture helpers.
"""
import argparse
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3
import socket
import sys
import threading
import time

STUDENT = Path(os.environ.get('DAY04_STUDENT_ROOT', str(Path(__file__).resolve().parents[2] / 'student'))) 
sys.path.insert(0, str(Path(__file__).resolve().parent))
import public_fixtures as t


def idempotent(gateway):
    req, f = t.request('300001','300000000001')
    ans = t.reply('0100', f)
    with t.gateway_env(gateway, {req: ans}) as (port, db, _):
        assert t.send(port, [req, req, req], expect=3) == [ans]*3
        t.await_rows(db, lambda rows: len(rows) >= 1 and rows[0]['status']=='APPROVED')
        time.sleep(.15)
        rr = t.rows(db)
        assert len(rr) == 1, f'duplicate request produced {len(rr)} transactions'
        assert rr[0]['outcome_code'] == '00'


def interleaved(gateway):
    a, af = t.request('300002','300000000002')
    b, bf = t.request('300003','300000000003',amount=8700)
    ar, br = t.reply('0100',af,'00'), t.reply('0100',bf,'05')
    with t.gateway_env(gateway, {a:ar,b:br}, reorder=True) as (port, db, auth):
        assert t.send(port, [a,b], expect=2) == [br, ar]
        rr = t.await_rows(db, lambda x: len(x)==2 and all(y['status']!='PENDING' for y in x))
        indexed={row['stan']:row for row in rr}
        assert indexed[af[11]]['outcome_code']=='00'
        assert indexed[bf[11]]['outcome_code']=='05'
        assert indexed[bf[11]]['amount_minor']==8700
        assert auth.received.count(a)==auth.received.count(b)==1


def date_context(gateway):
    today = datetime.now(timezone.utc)
    yesterday = today-timedelta(days=1)
    day_a, day_b = yesterday.strftime('%m%d'), today.strftime('%m%d')
    a, af=t.request('300004','300000000004',date=day_a)
    b, bf=t.request('300004','300000000004',date=day_b,amount=9900)
    ar, br=t.reply('0100',af,'00'),t.reply('0100',bf,'05')
    with t.gateway_env(gateway,{a:ar,b:br},reorder=True) as (port,db,_):
        assert t.send(port,[a,b],expect=2)==[br,ar]
        rr=t.await_rows(db,lambda x:len(x)==2 and all(y['status']!='PENDING' for y in x))
        dates={x['transaction_date'] for x in rr}
        assert len(dates)==2, f'date context lost: {dates}'
        results={x['amount_minor']:x['outcome_code'] for x in rr}
        assert results=={2500:'00',9900:'05'},results


def injection(gateway):
    malicious="X' OR 1=1--"
    req,fields=t.request('300005','300000000005',merchant=malicious)
    ans=t.reply('0100',fields)
    with t.gateway_env(gateway,{req:ans}) as (port,db,_):
        assert t.send(port,[req],expect=1)==[ans]
        rows=t.await_rows(db,lambda x:len(x)==1 and x[0]['status']=='APPROVED')
        assert rows[0]['merchant_ref']==malicious
        with sqlite3.connect(db) as conn:
            assert conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='transactions'").fetchone()
            assert conn.execute('SELECT count(*) FROM transactions').fetchone()[0]==1


def sensitive(gateway):
    pan='5555555555554444'
    req,fields=t.request('300006','300000000006',pan=pan)
    ans=t.reply('0100',fields)
    with t.gateway_env(gateway,{req:ans}) as (port,db,_):
        assert t.send(port,[req],expect=1)==[ans]
        t.await_rows(db,lambda x:len(x)==1 and x[0]['status']=='APPROVED')
        with sqlite3.connect(db) as conn:
            rows=list(conn.execute('SELECT * FROM transactions'))
            assert all(pan not in str(cell) for row in rows for cell in row)
            assert pan.encode() not in db.read_bytes(), 'PAN appeared in DB bytes'


def advice(gateway):
    req,f=t.request('300007','300000000007',mti='0220')
    ans=t.reply('0220',f)
    with t.gateway_env(gateway,{req:ans}) as (port,db,_):
        assert t.send(port,[req],expect=1)==[ans]
        r=t.await_rows(db,lambda x:len(x)==1 and x[0]['status']!='PENDING')[0]
        assert r['operation']=='ADVICE' and r['outcome_code']=='00'


def malformed(gateway):
    # Truncated LLVAR PAN: valid bitmap advertises DE2; wire has too few bytes.
    invalid = b'0100400000000000000019ABC'
    with t.gateway_env(gateway,{invalid:invalid}) as (port,db,auth):
        assert t.send(port,[invalid],expect=1)==[invalid]
        time.sleep(.1)
        assert t.rows(db)==[] and invalid in auth.received


def missing_reply(gateway):
    req,f=t.request('300008','300000000008')
    with t.gateway_env(gateway,{req:None},hold=True) as (port,db,_):
        t.send(port,[req],expect=0)
        r=t.await_rows(db,lambda x:len(x)==1)[0]
        assert r['status']=='PENDING' and r['outcome_code'] is None and r['completed_at'] is None


def locked_database(gateway):
    req,f=t.request('300009','300000000009')
    answer=t.reply('0100',f)
    with t.gateway_env(gateway,{req:answer}) as (port,db,auth):
        with sqlite3.connect(db,timeout=1) as blocker:
            blocker.execute('BEGIN IMMEDIATE')
            blocker.execute('INSERT INTO transactions (stan,rrn,transaction_date,operation,created_at) VALUES (?,?,?,?,?)',
                           ('BLOCK','BLOCK','2026-11-17','TEST','2026-11-17T00:00:00Z'))
            started=time.monotonic()
            assert t.send(port,[req],expect=1)==[answer]
            elapsed=time.monotonic()-started
            assert elapsed < 8, f'proxy blocked on locked database for {elapsed:.1f}s'
            blocker.rollback()
        assert req in auth.received


def response_other_tcp_session(gateway):
    # TCP connections are NOT the correlation key: server replies on connection B
    # although the request reached the authorizer on connection A.
    req, f = t.request('300010', '300000000010')
    ans = t.reply('0100', f)
    with t.gateway_env(gateway, {req: ans}, cross_route=True) as (port, db, auth):
        with socket.create_connection(('127.0.0.1',port),timeout=2) as conn_a, \
             socket.create_connection(('127.0.0.1',port),timeout=2) as conn_b:
            conn_a.settimeout(3)
            conn_b.settimeout(3)
            time.sleep(.15)  # ensure both independent authorizer connections exist
            conn_a.sendall(t.framed(req))
            assert t.receive(conn_b) == ans, 'reply did not cross via second TCP session'
            r = t.await_rows(db,lambda rows: len(rows)==1 and rows[0]['status']=='APPROVED')[0]
            assert r['rrn']==f[37] and r['stan']==f[11]
            assert req in auth.received


# All hidden tests are independent; each runs on a fresh database file.
CASES={'idempotent':idempotent,'interleaved':interleaved,'date_context':date_context,
       'sql_injection':injection,'no_pan_storage':sensitive,'advice':advice,
       'malformed':malformed,'pending_no_response':missing_reply,
       'db_locked_forwarding':locked_database,
       'response_other_tcp_session':response_other_tcp_session}


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--gateway',required=True)
    cli.add_argument('--case',choices=list(CASES))
    args=cli.parse_args()
    checks={args.case:CASES[args.case]} if args.case else CASES
    failed=0
    for name, callback in checks.items():
        try:
            callback(args.gateway)
            print('PASS',name,flush=True)
        except Exception as exc:
            failed+=1
            print('FAIL',name,repr(exc),flush=True)
    print(f'HIDDEN: {len(checks)-failed}/{len(checks)} scenarios passed')
    return 1 if failed else 0

if __name__=='__main__':sys.exit(main())
