#!/usr/bin/env python3
"""Grade student's schema-provisioning script; instructor-only assertions."""
import argparse
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile


def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('--student-root',required=True,type=Path)
    args=cli.parse_args()
    root=args.student_root.resolve()
    script=root/'tools'/'init_database.py'
    assert script.is_file(), 'database initialization script missing'
    with tempfile.TemporaryDirectory(prefix='day04-schema-') as tmp:
        target=Path(tmp)/'nested'/'transactions.sqlite'
        for reset in (True,False):
            result=subprocess.run([sys.executable,str(script),'--db',str(target)] + (['--reset'] if reset else []),
                                  capture_output=True,text=True,timeout=15)
            assert result.returncode==0, result.stdout+result.stderr
            with sqlite3.connect(target) as db:
                assert db.execute('PRAGMA journal_mode').fetchone()[0]=='wal', 'WAL not configured'
                required={'id','stan','rrn','transaction_date','cardholder_ref','merchant_ref',
                          'operation','amount_minor','currency','status','outcome_code','created_at','completed_at'}
                actual={row[1] for row in db.execute('PRAGMA table_info(transactions)')}
                assert actual>=required, sorted(required-actual)
                if reset:
                    db.execute("INSERT INTO transactions(stan,rrn,transaction_date,operation,created_at) "
                               "VALUES('A','B','2026-11-17','TEST','2026-11-17T00:00:00Z')")
                    db.commit()
                else:
                    assert db.execute('SELECT count(*) FROM transactions').fetchone()[0]==1, 'init erased data'
    print('PASS init_script')

if __name__=='__main__':main()
