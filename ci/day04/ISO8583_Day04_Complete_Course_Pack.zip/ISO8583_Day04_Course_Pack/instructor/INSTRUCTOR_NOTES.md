# Week 10 / Day 4 - Instructor notes

**Keep this directory private.** Students should receive only `student/`, not `instructor/`.

## Contents

- `answer_key.pdf` - five written answers, expected design, scoring notes.
- `grading/grade_day04.py` - one-shot compile, regression and graded black-box checks.
- `tests/test_database_wrapper.cpp` - six RAII and prepared-SQL cases, plus separate init-script validation.
- `tests/test_hidden_persistence.py` - ten private TCP/SQLite acceptance scenarios.
- `reference/` - **completed reference implementation** for instructors; never ship to students.
- `REFERENCE_TEST_RESULTS.txt` - locally verified test transcript.

## How to grade

1. Clone submitted repository to a clean directory.
2. Run:

```sh
python3 instructor/grading/grade_day04.py --student-root /path/to/cloned/day04
```

The script creates a separate CMake build directory, executes the old Day 3 regression,
compiles the SQLite wrapper tests, and runs the public and hidden black-box scenarios.
Every black-box scenario creates an empty temporary SQLite DB via the **student's**
`tools/init_database.py` and runs a gateway whose `ISO8583_DB_PATH` points at it.
All gateway traffic comes from synthetic test fixtures; full PANs must never appear
in the resulting transaction rows.

Score: five groups, 15 + 15 + 15 + 20 + 10 = **75 practical points**.
Five general SQL/database questions: **25 manual points**.
Test grouping and points are listed in the grader source. Score the *observable
behavior*, not a student's implementation style; equivalent safe solutions qualify.

## Limitations and known profile decisions

- This is a classroom NIBSS-inspired ISO8583 lab, not a formal payment network certification.
- Requests/responses checked: 0100/0110, 0200/0210, 0220/0230, 0420/0430.
- A reversal is a new operation; it does not overwrite the initial purchase.
- The test wire encoder includes only NIBSS fields used by the test scenario; no simulator-specific DE70.
- DE13 is MMDD and needs a year from UTC context; year transitions are tested.
- The SQLite DB path is supplied as an environment variable to preserve the Day 3 CLI.
- The day 4 gateway is still a transparent proxy; it cannot reject merchants or generate ISO8583 replies.
- The public TCP simulator check uses a local test authorizer. Prior Day 3 GitHub Actions
  separately validated the parser/gateway transport against the real course simulator;
  these Day 4 persistence tests do **not** assert that the simulator is the source of the transactions.
- The wrapper `Statement` must be destroyed before its `Database`, and `Transaction` must not
  outlive its `Database`. Missing ownership checks should be discussed during code review.
- Test fixture `cardholder_ref` may be NULL; the student must not persist raw PAN.
- Status code mapping for this exercise: DE39 00 => APPROVED; any other DE39 => DECLINED.
- The Day 4 hidden tests do not prove the implementation is production-ready. In particular,
  crash-safe reconciliation, full payment privacy controls and cross-day reversal policies
  are outside the current practical scope.

## Expected commands

```sh
cmake -S student -B /tmp/day04-build -DBUILD_TESTING=ON
cmake --build /tmp/day04-build -j2
ctest --test-dir /tmp/day04-build --output-on-failure
python3 student/tests/test_gateway_integration.py --gateway /tmp/day04-build/gateway
python3 student/tests/public/test_persistence.py --gateway /tmp/day04-build/gateway
python3 instructor/grading/grade_day04.py --student-root student
```

The starter's Day 4 persistence tests **must fail**; methods are intentionally TODO.
The instructor reference must pass the grading suite.
