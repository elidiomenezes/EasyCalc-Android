#!/usr/bin/env python3
"""Instructor-only grading tool for Week 10 Day 4.

Usage:
  python3 instructor/grading/grade_day04.py --student-root student
  python3 instructor/grading/grade_day04.py --student-root /tmp/clone --build-dir /tmp/day04-build

Tests operate on a fresh SQLite database for each scenario. The supplied skeleton
intentionally does not pass Day 4 tests until implemented by the student.
"""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile

BASE = Path(__file__).resolve().parents[1]
PUBLIC = BASE / 'tests' / 'public_fixtures.py'
HIDDEN = BASE / 'tests' / 'test_hidden_persistence.py'
RAII = BASE / 'tests' / 'test_database_wrapper.cpp'

# One case can support multiple learning objectives, but is scored in one group only.
GROUPS = {
    'Database foundation / RAII': (15, [
        ('raii', 'connection'), ('raii', 'rollback'), ('raii', 'commit'),
        ('init', 'init_script'),
    ]),
    'Parameterized SQL / safety': (15, [
        ('raii', 'bound'), ('raii', 'moves'), ('raii', 'reject_tail'),
    ]),
    'Financial event mapping': (15, [
        ('public', 'authorized'), ('public', 'declined'), ('public', 'reversal'),
        ('hidden', 'advice'), ('hidden', 'no_pan_storage'), ('public', 'network'),
    ]),
    'Request/response correlation': (20, [
        ('public', 'pending'), ('hidden', 'pending_no_response'),
        ('hidden', 'idempotent'),
        ('hidden', 'interleaved'), ('hidden', 'date_context'),
        ('hidden', 'response_other_tcp_session'),
    ]),
    'Gateway transparency / concurrency': (10, [
        ('public', 'parallel'), ('hidden', 'malformed'),
        ('hidden', 'sql_injection'), ('hidden', 'db_locked_forwarding'),
    ]),
}


def call(command, *, env=None, timeout=90):
    try:
        return subprocess.run(command, env=env, capture_output=True,
                              text=True, timeout=timeout)
    except (subprocess.TimeoutExpired, OSError) as exc:
        class Result:
            returncode = 124
            stdout = ''
            stderr = str(exc)
        return Result()


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--student-root', type=Path, required=True)
    cli.add_argument('--build-dir', type=Path)
    args=cli.parse_args()
    root=args.student_root.resolve()
    for path in ['CMakeLists.txt','src/database.cpp','include/database.hpp',
                 'src/session.cpp','schema.sql']:
        if not (root/path).is_file():
            cli.error(f'missing student file: {root/path}')
    with tempfile.TemporaryDirectory(prefix='day04-grade-') as work:
        build=(args.build_dir or Path(work)/'build').resolve()
        configured=call(['cmake','-S',str(root),'-B',str(build),'-DBUILD_TESTING=ON'])
        if configured.returncode:
            print('FAIL CMake configure:\n'+configured.stderr[-3000:]);return 1
        built=call(['cmake','--build',str(build),'--parallel','2'],timeout=180)
        if built.returncode:
            print('FAIL CMake build:\n'+built.stderr[-3000:]);return 1
        gateway=build/'gateway'
        if not gateway.is_file():
            print('FAIL missing gateway executable');return 1
        suite=call(['ctest','--test-dir',str(build),'--output-on-failure'])
        print('DAY 3 REGRESSION', 'PASS' if suite.returncode==0 else 'FAIL')
        if suite.returncode: print((suite.stdout+suite.stderr)[-2500:])
        wrapper=Path(work)/'test_database_wrapper'
        compiled=call(['g++','-std=c++17','-Wall','-Wextra','-Wpedantic','-Wconversion',
                       '-I',str(root/'include'),str(root/'src/database.cpp'),
                       str(RAII),'-lsqlite3','-o',str(wrapper)],timeout=90)
        if compiled.returncode:
            print('FAIL wrapper test compilation:\n'+compiled.stderr[-3000:]);return 1
        env=dict(os.environ,DAY04_STUDENT_ROOT=str(root))
        total=0.0
        for group,(points,cases) in GROUPS.items():
            passed=0
            print(f'\n{group} ({points} points)')
            for family,name in cases:
                if family=='raii': command=[str(wrapper),name]
                elif family=='init': command=[sys.executable,str(BASE/'tests'/'test_init_database.py'),'--student-root',str(root)]
                elif family=='public': command=[sys.executable,str(PUBLIC),'--gateway',str(gateway),'--case',name]
                else: command=[sys.executable,str(HIDDEN),'--gateway',str(gateway),'--case',name]
                result=call(command,env=env,timeout=35)
                ok=result.returncode==0
                passed+=int(ok)
                print(' ', 'PASS' if ok else 'FAIL', name)
                if not ok: print('   '+(result.stdout+result.stderr).strip()[-750:].replace('\n','\n   '))
            grade=points*passed/len(cases)
            total+=grade
            print(f'  {grade:.2f}/{points} ({passed}/{len(cases)})')
        print(f'\nPRACTICAL: {total:.2f}/75')
        print('WRITTEN QUESTIONS: 25 points, graded manually from answer key')
        print('COURSE TOTAL: practical + written / 100')
        return 0 if total==75 and suite.returncode==0 else 1


if __name__=='__main__':sys.exit(main())
