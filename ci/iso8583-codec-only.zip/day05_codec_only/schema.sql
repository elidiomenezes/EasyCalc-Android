CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY,
    stan TEXT NOT NULL,
    rrn TEXT NOT NULL,
    transaction_date TEXT NOT NULL,
    cardholder_ref TEXT,
    merchant_ref TEXT,
    operation TEXT NOT NULL,
    amount_minor INTEGER,
    currency TEXT,
    status TEXT NOT NULL DEFAULT 'PENDING',
    outcome_code TEXT,
    created_at TEXT NOT NULL,
    completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_transactions_correlation
    ON transactions(stan, rrn, transaction_date);
