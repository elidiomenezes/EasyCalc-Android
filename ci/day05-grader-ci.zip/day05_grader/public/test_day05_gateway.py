#!/usr/bin/env python3
"""Day 5 gateway black-box tests. Only Python standard library required.

These tests inspect real framed TCP traffic and the actual SQLite outcome.
"""
import argparse
import importlib.util
from pathlib import Path
import socket
import sys
import time

DAY4 = Path(__file__).resolve().parents[2] / 'day05_codec_only/tests/public/test_persistence.py'
spec = importlib.util.spec_from_file_location('day4_harness', DAY4)
day4 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(day4)

def decode(wire):
    text = wire.decode('ascii')
    mti = text[:4]
    bits = int(text[4:20], 16)
    offset = 20
    fields = {}
    for de in range(2, 65):
        if not bits & (1 << (64-de)): continue
        mode, width = day4.SPECS[de]
        if mode == 'v':
            length = int(text[offset:offset+width]); offset += width
        else: length = width
        fields[de] = text[offset:offset+length]; offset += length
    assert offset == len(text), ('trailing response bytes', text[offset:])
    return mti, fields

def check_no_upstream(observer):
    time.sleep(.08)
    assert observer.received == [], f'locally rejected request leaked upstream: {len(observer.received)}'

def local_case(binary, *, amount=2500, pan='4111111111111111', merchant='MERCHANT0000001',
               expected='61', fragmented=False, fields_override=None):
    req, fields = day4.request(amount=amount, pan=pan, merchant=merchant)
    if fields_override:
        fields = fields_override(fields)
        req = day4.wire('0100',fields)
    with day4.gateway_env(binary, {}) as (port, database, observer):
        with socket.create_connection(('127.0.0.1',port),timeout=2) as client:
            client.settimeout(2)
            frame = day4.framed(req)
            start = time.monotonic()
            if fragmented:
                client.sendall(frame[:1]); time.sleep(.02)
                client.sendall(frame[1:9]); time.sleep(.02)
                client.sendall(frame[9:])
            else: client.sendall(frame)
            reply = day4.receive(client)
            elapsed = time.monotonic()-start
            assert elapsed < 2, f'local rejection took {elapsed:.2f}s'
            mti, outcome = decode(reply)
            assert mti == '0110', mti
            assert outcome[39] == expected, outcome
        check_no_upstream(observer)
        result=day4.await_rows(database,lambda r: len(r)==1 and r[0]['status']=='DECLINED')
        assert result[0]['outcome_code']==expected, result

def allowed(binary, *, amount=999999, merchant='MERCHANT0000010'):
    req, fields = day4.request(amount=amount,merchant=merchant)
    reply=day4.reply('0100',fields,outcome='05')
    with day4.gateway_env(binary,{req:reply}) as (port,database,observer):
        with socket.create_connection(('127.0.0.1',port),timeout=2) as client:
            client.settimeout(2)
            client.sendall(day4.framed(req))
            assert day4.receive(client)==reply, 'upstream response modified'
        assert observer.received==[req], 'allowed request modified or duplicated'
        result=day4.await_rows(database,lambda r:len(r)==1 and r[0]['status']=='DECLINED')
        assert result[0]['outcome_code']=='05'

def amount(binary): local_case(binary,amount=1000000,expected='61')
def luhn(binary): local_case(binary,pan='4111111111111112',expected='14')
def merchant(binary): local_case(binary,merchant='MERCHANT0000011',expected='03')
def fragments(binary): local_case(binary,amount=1000001,expected='61',fragmented=True)
def precedence(binary): local_case(binary,amount=1000000,pan='4111111111111112',merchant='MERCHANT0000011',expected='61')
def missing(binary):
    local_case(binary,expected='30',fields_override=lambda f:{k:v for k,v in f.items() if k!=2})

def bad_bitmap(binary):
    req,_=day4.request()
    invalid=req[:4]+b'Z'+req[5:]
    with day4.gateway_env(binary,{}) as (port,database,observer):
        with socket.create_connection(('127.0.0.1',port),timeout=2) as client:
            client.settimeout(1)
            client.sendall(day4.framed(invalid))
            try:
                data=client.recv(512)
                assert not data, 'unexpected response to unparseable message'
            except (socket.timeout,ConnectionResetError,BrokenPipeError): pass
        check_no_upstream(observer)
        assert day4.rows(database)==[]

CASES={'allowed':allowed,'amount':amount,'luhn':luhn,'merchant':merchant,
       'fragments':fragments,'precedence':precedence,'missing':missing,'bad_bitmap':bad_bitmap}

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--gateway',required=True)
    ap.add_argument('--case',choices=[*CASES,'all'],default='all')
    args=ap.parse_args()
    cases=list(CASES) if args.case=='all' else [args.case]
    for name in cases:
        CASES[name](args.gateway)
        print(f'PASS day05_{name}',flush=True)
