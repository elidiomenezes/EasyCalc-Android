# Day 5 public gateway tests

Place `day05_grader/public/` beside the `day05_codec_only/` project directory.
The script reuses the Python standard-library network/SQLite fixture in
`day05_codec_only/tests/public/test_persistence.py`.

Build your gateway and run:

    python3 day05_grader/public/test_day05_gateway.py \
      --gateway ./day05_codec_only/build/gateway

Run one scenario with `--case amount`, `--case luhn`, `--case merchant`,
`--case allowed`, `--case fragments`, `--case precedence`, `--case missing`,
or `--case bad_bitmap`.

The tests create temporary databases and loopback sockets. They do not
modify a student's existing transactions database.
