#!/usr/bin/env python3
"""Instructor-only black-box cases. Do not distribute with student starter."""
import argparse
import importlib.util
from pathlib import Path
import socket
import time

PUBLIC = Path(__file__).resolve().parents[1] / 'public/test_day05_gateway.py'
spec=importlib.util.spec_from_file_location('day05_public',PUBLIC)
pub=importlib.util.module_from_spec(spec)
spec.loader.exec_module(pub)
d=pub.day4

def amount_below(binary): pub.allowed(binary, amount=999999)
def amount_zero(binary): pub.allowed(binary, amount=0)
def last_merchant(binary): pub.allowed(binary, merchant='MERCHANT0000010')
def pan_length(binary): pub.local_case(binary,pan='411111111111111',expected='14')
def pan_chars(binary): pub.local_case(binary,pan='41111111111111XX',expected='14')

def fragment_valid(binary):
    req, fields=d.request()
    reply=d.reply('0100',fields)
    with d.gateway_env(binary,{req:reply}) as (port,db,observer):
        with socket.create_connection(('127.0.0.1',port),timeout=2) as client:
            client.settimeout(2)
            frame=d.framed(req)
            for fragment in (frame[:1],frame[1:7],frame[7:35],frame[35:]):
                client.sendall(fragment)
                time.sleep(.004)
            assert d.receive(client)==reply
        assert observer.received==[req]

def two_frames(binary):
    first, f1=d.request(stan='300001',rrn='123456789111',amount=1000000)
    second, f2=d.request(stan='300002',rrn='123456789112',amount=3500)
    upstream=d.reply('0100',f2)
    with d.gateway_env(binary,{second:upstream}) as (port,db,observer):
        with socket.create_connection(('127.0.0.1',port),timeout=2) as client:
            client.settimeout(3)
            client.sendall(d.framed(first)+d.framed(second))
            responses=[d.receive(client),d.receive(client)]
            outcomes={pub.decode(item)[1][39] for item in responses}
            assert outcomes=={'61','00'},outcomes
        assert observer.received==[second]
        result=d.await_rows(db,lambda r:len(r)==2 and all(x['status']!='PENDING' for x in r))
        assert {x['outcome_code'] for x in result}=={'61','00'}

def network_bypass(binary):
    req, fields=d.request(mti='0220')
    response=d.reply('0220',fields)
    with d.gateway_env(binary,{req:response}) as (port,db,observer):
        with socket.create_connection(('127.0.0.1',port),timeout=2) as client:
            client.settimeout(3)
            client.sendall(d.framed(req))
            assert d.receive(client)==response
        assert observer.received==[req]

def no_upstream_wait(binary):
    req,_=d.request(amount=1000000)
    with d.gateway_env(binary,{},hold=True) as (port,db,observer):
        with socket.create_connection(('127.0.0.1',port),timeout=2) as client:
            client.settimeout(2)
            start=time.monotonic()
            client.sendall(d.framed(req))
            assert pub.decode(d.receive(client))[1][39]=='61'
            assert time.monotonic()-start<1.5, 'local decision waited for upstream'
        pub.check_no_upstream(observer)

def zero_frame(binary):
    with d.gateway_env(binary,{}) as (port,db,observer):
        with socket.create_connection(('127.0.0.1',port),timeout=2) as client:
            client.settimeout(1)
            client.sendall(b'\x00\x00')
            try:
                assert not client.recv(128)
            except (socket.timeout,ConnectionResetError): pass
        pub.check_no_upstream(observer)
        assert d.rows(db)==[]

CASES={'amount_below':amount_below,'amount_zero':amount_zero,'last_merchant':last_merchant,
       'pan_length':pan_length,'pan_chars':pan_chars,'fragment_valid':fragment_valid,
       'two_frames':two_frames,'advice_bypass':network_bypass,
       'no_upstream_wait':no_upstream_wait,'zero_frame':zero_frame}

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--gateway',required=True)
    ap.add_argument('--case',choices=[*CASES,'all'],default='all')
    args=ap.parse_args()
    for name in (CASES if args.case=='all' else [args.case]):
        CASES[name](args.gateway)
        print(f'PASS reserved_{name}',flush=True)
