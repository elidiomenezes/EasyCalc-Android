# Week 10 Day 5: gateway policy grader

Run the black-box grader against an executable accepting:

    gateway LISTEN_IPV4:PORT AUTHORIZER_IPV4:PORT

The gateway must honor `ISO8583_DB_PATH` and use the supplied `schema.sql`.
The grader creates isolated loopback TCP endpoints, a temporary SQLite file,
and a deterministic fake upstream host. It never needs the Python simulator.

## Public tests

    python3 day05_grader/public/test_day05_gateway.py \
      --gateway /absolute/path/to/gateway

Cases: allowed, amount, luhn, merchant, fragments, precedence, missing,
bad_bitmap. The same script also supports `--case NAME`.

## Instructor-only tests

    python3 day05_grader/reserved/test_day05_reserved.py \
      --gateway /absolute/path/to/gateway

Keep `reserved/` out of student distributions. The reference solution in
`reference/` is likewise instructor-only. Public and reserved code is
independent of the gateway implementation, and checks real TCP bytes and
SQLite outcomes.

## Build and run reference

    cmake -S day05_grader/reference -B build -DDAY05_RESERVED_TESTS=ON
    cmake --build build -j2
    ctest --test-dir build -R '^day05_' --output-on-failure

The Day 4 transparent-proxy tests that intentionally forward malformed ISO
frames are superseded by Day 5's explicit invalid-frame policy. Those tests
are not a Day 5 acceptance requirement. Codec, SQLite and valid financial
persistence regressions remain relevant.

## Weighting

Practical: 75 points (policy 25; routing 20; invalid input 10;
SQLite 10; timing/diagnostics 10). The five written answers are 25 points.
The grader exercises behavior. Human review remains necessary for safe logging,
robust timeout handling, and the five theoretical answers.

Tests intentionally use relaxed wall-clock deadlines; they do not establish
hard real-time latency guarantees or measure code coverage.
