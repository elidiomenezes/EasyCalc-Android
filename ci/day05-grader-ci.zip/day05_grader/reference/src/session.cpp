#include "session.hpp"
#include "logger.hpp"
#include "iso8583_parser.hpp"
#include <stdexcept>
#include <string>
#include <algorithm>
#include <unistd.h>
#include <ctime>
#include <cstdlib>
#include <cstdint>
#include <memory>
#include <chrono>
#include <limits>
namespace payment_gateway {
namespace {
std::string now_utc() {
    const auto t=std::time(nullptr);
    std::tm tm{};
    gmtime_r(&t,&tm);
    char buffer[32];
    std::strftime(buffer,sizeof(buffer),"%Y-%m-%dT%H:%M:%SZ",&tm);
    return buffer;
}
std::string transaction_date(const std::string& mmdd) {
    if(mmdd.size()!=4 || mmdd.find_first_not_of("0123456789")!=std::string::npos)
        throw DatabaseError("invalid transaction date");
    const int mm=std::stoi(mmdd.substr(0,2)),dd=std::stoi(mmdd.substr(2,2));
    if(mm<1||mm>12||dd<1||dd>31)throw DatabaseError("invalid transaction date");
    std::time_t current=std::time(nullptr);
    std::tm now{};gmtime_r(&current,&now);
    std::tm candidate=now;
    candidate.tm_mon=mm-1;candidate.tm_mday=dd;
    candidate.tm_hour=12;candidate.tm_min=0;candidate.tm_sec=0;
    candidate.tm_isdst=0;
    std::time_t timestamp=timegm(&candidate);
    if(timestamp>current+15552000) candidate.tm_year-=1;
    else if(timestamp<current-15552000)candidate.tm_year+=1;
    candidate.tm_hour=12;
    timestamp=timegm(&candidate);
    std::tm checked{};gmtime_r(&timestamp,&checked);
    if(checked.tm_mon!=mm-1||checked.tm_mday!=dd)throw DatabaseError("invalid transaction date");
    char result[11];std::strftime(result,sizeof(result),"%Y-%m-%d",&checked);
    return result;
}
std::string right_trim(std::string v) {
    while(!v.empty() && v.back()==' ')v.pop_back();
    return v;
}
bool luhn(const std::string& pan) {
    if(pan.size()<12 || pan.size()>19)return false;
    unsigned sum=0;
    bool double_digit=false;
    for(auto pos=pan.rbegin();pos!=pan.rend();++pos){
        if(*pos<'0'||*pos>'9')return false;
        unsigned digit=static_cast<unsigned>(*pos-'0');
        if(double_digit){digit*=2; if(digit>9)digit-=9;}
        sum+=digit;
        double_digit=!double_digit;
    }
    return sum%10==0;
}
std::string correlation(const ParsedMessage& msg){
    return msg.fields[11]+"/"+msg.fields[37];
}
std::string frame_payload(const std::string& payload){
    if(payload.empty() || payload.size()>65535)throw ComposeError("invalid frame size");
    const auto length=static_cast<unsigned>(payload.size());
    std::string frame;
    frame.reserve(payload.size()+2);
    frame.push_back(static_cast<char>((length>>8)&0xff));
    frame.push_back(static_cast<char>(length&0xff));
    return frame+payload;
}
}
void Session::record_transaction(const ParsedMessage& msg, const char* direction) {
    if(!database_)return;
    static constexpr struct {const char* req;const char* response;const char* op;} types[]={
        {"0100","0110","AUTHORIZATION"},
        {"0200","0210","FINANCIAL"},
        {"0220","0230","ADVICE"},
        {"0420","0430","REVERSAL"}
    };
    const bool is_request=std::string(direction)=="request";
    const char* operation=nullptr;
    for(const auto& type:types){
        if(msg.mti==(is_request?type.req:type.response)) {operation=type.op;break;}
    }
    if(!operation)return;
    if(!msg.present[11]||!msg.present[37]||!msg.present[13])return;
    const std::string& stan=msg.fields[11];
    const std::string& rrn=msg.fields[37];
    const std::string day=transaction_date(msg.fields[13]);
    auto tx=database_->begin_transaction();
    if(is_request){
        auto existing=database_->prepare(
            "SELECT id FROM transactions WHERE stan=:stan AND rrn=:rrn "
            "AND transaction_date=:day AND operation=:operation LIMIT 1");
        existing.bind(":stan",std::string_view(stan));
        existing.bind(":rrn",std::string_view(rrn));
        existing.bind(":day",std::string_view(day));
        existing.bind(":operation",std::string_view(operation));
        if(existing.step()) {tx.commit();return;}
        if(!msg.present[4])return;
        const auto amount=static_cast<std::int64_t>(std::stoll(msg.fields[4]));
        auto insert=database_->prepare(
            "INSERT INTO transactions(stan,rrn,transaction_date,cardholder_ref,merchant_ref,"
            "operation,amount_minor,currency,status,outcome_code,created_at,completed_at) "
            "VALUES(:stan,:rrn,:day,NULL,:merchant,:op,:amount,:currency,'PENDING',NULL,:created,NULL)");
        insert.bind(":stan",std::string_view(stan));
        insert.bind(":rrn",std::string_view(rrn));
        insert.bind(":day",std::string_view(day));
        insert.bind(":merchant",std::string_view(msg.present[42]?right_trim(msg.fields[42]):""));
        insert.bind(":op",std::string_view(operation));
        insert.bind(":amount",amount);
        insert.bind(":currency",std::string_view(msg.present[49]?msg.fields[49]:""));
        const std::string received=now_utc();
        insert.bind(":created",std::string_view(received));
        (void)insert.step();
    } else {
        if(!msg.present[39])return;
        auto update=database_->prepare(
            "UPDATE transactions SET status=:status, outcome_code=:code,completed_at=:completed "
            "WHERE id=(SELECT id FROM transactions WHERE stan=:stan AND rrn=:rrn "
            "AND transaction_date=:day AND operation=:operation ORDER BY id DESC LIMIT 1) "
            "AND status='PENDING'");
        const std::string status=msg.fields[39]=="00"?"APPROVED":"DECLINED";
        update.bind(":status",std::string_view(status));
        update.bind(":code",std::string_view(msg.fields[39]));
        const std::string completed=now_utc();
        update.bind(":completed",std::string_view(completed));
        update.bind(":stan",std::string_view(stan));
        update.bind(":rrn",std::string_view(rrn));
        update.bind(":day",std::string_view(day));
        update.bind(":operation",std::string_view(operation));
        (void)update.step();
    }
    tx.commit();
}

bool Session::send_decline(const ParsedMessage& request,const std::string& code){
    static const Iso8583Parser codec{};
    ParsedMessage response{};
    response.mti=request.mti=="0100"?"0110":"0210";
    for(unsigned de:{3U,4U,7U,11U,12U,13U,37U,41U,42U,49U}){
        if(request.present[de]){
            response.present[de]=true;
            response.fields[de]=request.fields[de];
        }
    }
    response.present[39]=true;
    response.fields[39]=code;
    try {
        auto frame=frame_payload(codec.compose(response));
        try {record_transaction(request,"request");record_transaction(response,"response");}
        catch(const std::exception& error){log(std::string("Persistence failure: ")+error.what());}
        enqueue_client(std::move(frame));
        log("local_decline outcome="+code+" elapsed_ms=0");
        return true;
    }catch(const ComposeError& error){log(std::string("Response composition failed: ")+error.what());stop();return false;}
}

bool Session::process_request(const std::string& frame,const std::string& payload){
    static const Iso8583Parser codec{};
    ParsedMessage request{};
    try {request=codec.parse(payload);}
    catch(const ParseError& error){log(std::string("Invalid ISO frame: ")+error.what());stop();return false;}
    if(request.mti=="0100" || request.mti=="0200"){
        const auto started=std::chrono::steady_clock::now();
        std::string code;
        if(!request.present[2] || !request.present[4] || !request.present[42])code="30";
        else {
            const auto& digits=request.fields[4];
            if(digits.size()!=12 || digits.find_first_not_of("0123456789")!=std::string::npos)code="30";
            else if(std::stoull(digits)>=1000000ULL)code="61";
            else if(!luhn(request.fields[2]))code="14";
            else if(!database_)code="96";
            else {
                try {
                    auto select=database_->prepare("SELECT 1 FROM authorized_merchants WHERE merchant_ref=:merchant LIMIT 1");
                    select.bind(":merchant",std::string_view(request.fields[42]));
                    if(!select.step())code="03";
                }catch(const std::exception& error){log(std::string("Merchant lookup failed: ")+error.what());code="96";}
            }
        }
        if(!code.empty()){
            const auto elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-started).count();
            log("local_policy outcome="+code+" elapsed_ms="+std::to_string(elapsed));
            return send_decline(request,code);
        }
    }
    try {record_transaction(request,"request");}
    catch(const std::exception& error){log(std::string("Persistence failed: ")+error.what());}
    outstanding_[correlation(request)]=std::chrono::steady_clock::now();
    enqueue_authorizer(frame);
    return true;
}

void Session::process_response(const std::string& frame,const std::string& payload){
    static const Iso8583Parser codec{};
    try {
        const auto message=codec.parse(payload);
        try {record_transaction(message,"response");}
        catch(const std::exception& error){log(std::string("Persistence failed: ")+error.what());}
        const auto key=correlation(message);
        const auto it=outstanding_.find(key);
        if(it!=outstanding_.end()){
            const auto elapsed=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-it->second).count();
            log("upstream_response elapsed_ms="+std::to_string(elapsed));
            outstanding_.erase(it);
        }
    }catch(const ParseError& error){log(std::string("Invalid upstream ISO frame: ")+error.what());}
    enqueue_client(frame);
}

void Session::observe_frames(std::string& pending,const char* data,std::size_t size,const char* direction){
    pending.append(data,size);
    while(!stopped_ && pending.size()>=2){
        const auto hi=static_cast<unsigned char>(pending[0]);
        const auto lo=static_cast<unsigned char>(pending[1]);
        const std::size_t length=(static_cast<std::size_t>(hi)<<8U)|lo;
        if(length==0){log("Invalid TCP frame length");stop();return;}
        if(pending.size()<length+2)return;
        const auto frame=pending.substr(0,length+2);
        const auto payload=pending.substr(2,length);
        pending.erase(0,length+2);
        if(std::string(direction)=="request"){
            if(!process_request(frame,payload))return;
        }else process_response(frame,payload);
    }
}

void Session::enqueue_client(std::string frame){
    const bool idle=client_queue_.empty();
    client_queue_.push_back(std::move(frame));
    if(idle)write_client();
}
void Session::enqueue_authorizer(std::string frame){
    const bool idle=authorizer_queue_.empty();
    authorizer_queue_.push_back(std::move(frame));
    if(idle)write_authorizer();
}
void Session::write_client(){
    if(stopped_ || client_queue_.empty())return;
    auto self=shared_from_this();
    asio::async_write(client_,asio::buffer(client_queue_.front()),[self](const boost::system::error_code& error,std::size_t){
        if(error){self->stop();return;}
        self->client_queue_.pop_front();
        self->write_client();
    });
}
void Session::write_authorizer(){
    if(stopped_ || authorizer_queue_.empty())return;
    auto self=shared_from_this();
    asio::async_write(authorizer_,asio::buffer(authorizer_queue_.front()),[self](const boost::system::error_code& error,std::size_t){
        if(error){self->stop();return;}
        self->authorizer_queue_.pop_front();
        self->write_authorizer();
    });
}
Session::Session(asio::io_context& io,tcp::endpoint destination)
    : client_(io),authorizer_(io),destination_(destination) {
    const char* path=std::getenv("ISO8583_DB_PATH");
    if(path && *path) {
        try {database_=std::make_unique<Database>(path);}
        catch(const std::exception& error){log(std::string("Database unavailable: ")+error.what());}
    }
}
tcp::socket& Session::client(){return client_;}
void Session::start() {
    boost::system::error_code error;
    authorizer_.connect(destination_,error);
    if(error){log("Authorizer connection failed: "+error.message());stop();return;}
    read_client();read_authorizer();
}
void Session::read_client() {
    auto self=shared_from_this();
    client_.async_read_some(asio::buffer(to_authorizer_),[self](const boost::system::error_code& error,std::size_t bytes){
        if(self->stopped_)return;
        if(error==asio::error::eof){self->client_eof_=true;self->half_close(self->authorizer_);self->finish_if_done();}
        else if(error){self->stop();}
        else {
            self->observe_frames(self->pending_requests_,self->to_authorizer_.data(),bytes,"request");
            if(!self->stopped_)self->read_client();
        }
    });
}
void Session::read_authorizer() {
    auto self=shared_from_this();
    authorizer_.async_read_some(asio::buffer(to_client_),[self](const boost::system::error_code& error,std::size_t bytes){
        if(self->stopped_)return;
        if(error==asio::error::eof){self->authorizer_eof_=true;self->half_close(self->client_);self->finish_if_done();}
        else if(error){self->stop();}
        else {
            self->observe_frames(self->pending_responses_,self->to_client_.data(),bytes,"response");
            if(!self->stopped_)self->read_authorizer();
        }
    });
}
void Session::half_close(tcp::socket& socket) {
    boost::system::error_code ignored;
    socket.shutdown(tcp::socket::shutdown_send,ignored);
}
void Session::finish_if_done(){if(client_eof_ && authorizer_eof_)stop();}
void Session::stop(){
    if(stopped_)return;
    stopped_=true;
    boost::system::error_code ignored;
    client_.close(ignored);
    authorizer_.close(ignored);
}
void serve_client(tcp::socket::native_handle_type fd,tcp::endpoint destination){
    try {
        asio::io_context io;
        auto session=std::make_shared<Session>(io,destination);
        boost::system::error_code error;
        session->client().assign(tcp::v4(),fd,error);
        if(error){::close(fd);throw std::runtime_error("Socket assignment: "+error.message());}
        session->start();io.run();
    }catch(const std::exception& error){log(std::string("Session failure: ")+error.what());}
}
}
