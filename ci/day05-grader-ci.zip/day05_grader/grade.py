#!/usr/bin/env python3
"""Grade Week 10 Day 5 practical submission (75 points). Python stdlib only.

The 25 theoretical points are scored separately by the instructor.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
PUBLIC=ROOT/'public/test_day05_gateway.py'
RESERVED=ROOT/'reserved/test_day05_reserved.py'
PERSISTENCE=ROOT.parent/'day05_codec_only/tests/public/test_persistence.py'

# Independent pass/fail cases. Each case is worth the declared number of points.
PLAN={
 'Policy checks':[
   ('public','amount',4),('reserved','amount_below',2),('reserved','amount_zero',2),
   ('public','luhn',5),('reserved','pan_length',2),('reserved','pan_chars',2),
   ('public','merchant',4),('reserved','last_merchant',2),('reserved','merchant_database_error',2)],
 'Routing and local responses':[
   ('public','allowed',7),('public','fragments',3),('public','precedence',3),
   ('reserved','two_frames',4),('reserved','advice_bypass',3)],
 'Invalid messages':[
   ('public','missing',4),('public','bad_bitmap',4),('reserved','zero_frame',2)],
 'SQLite integration':[
   ('persistence','authorized',2),('persistence','declined',2),
   ('persistence','pending',2),('persistence','reversal',2),
   ('persistence','parallel',2)],
 'Timing and diagnostics':[
   ('reserved','no_upstream_wait',4),('reserved','upstream_timeout',6)]
}
assert sum(points for cases in PLAN.values() for _,_,points in cases)==75

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--gateway',required=True,type=Path)
    ap.add_argument('--report',type=Path,help='Optional output JSON filename')
    args=ap.parse_args()
    gateway=args.gateway.resolve()
    if not gateway.is_file(): ap.error('gateway executable not found')
    results=[]
    for group,cases in PLAN.items():
        for source,name,points in cases:
            script={'public':PUBLIC,'reserved':RESERVED,'persistence':PERSISTENCE}[source]
            run=subprocess.run([sys.executable,str(script),'--gateway',str(gateway),'--case',name],
                               capture_output=True,text=True,timeout=20)
            passed=run.returncode==0
            results.append({'category':group,'case':name,'source':source,
                            'earned':points if passed else 0,'possible':points,
                            'passed':passed,
                            'diagnostic':(run.stdout+run.stderr).strip()[-1000:] if not passed else ''})
            print(f'{"PASS" if passed else "FAIL"} {group}/{name} '
                  f'{points if passed else 0}/{points}',flush=True)
    categories={}
    for label in PLAN:
        section=[r for r in results if r['category']==label]
        categories[label]={'earned':sum(r['earned'] for r in section),
                           'possible':sum(r['possible'] for r in section)}
    report={'practical':{'earned':sum(r['earned'] for r in results),'possible':75},
            'theory':{'earned':None,'possible':25,'grading':'manual'},
            'categories':categories,'cases':results}
    print(json.dumps({'practical':report['practical'],'categories':categories},indent=2))
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return 0 if report['practical']['earned']==75 else 1

if __name__=='__main__':
    try:sys.exit(main())
    except subprocess.TimeoutExpired as error:
        print(f'Grader timed out waiting for case: {error.cmd}',file=sys.stderr)
        sys.exit(2)
