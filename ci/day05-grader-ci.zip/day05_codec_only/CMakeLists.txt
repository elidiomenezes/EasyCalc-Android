cmake_minimum_required(VERSION 3.16)
project(iso8583_day03_gateway LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
add_library(iso8583_parser STATIC src/iso8583_parser.cpp)
target_include_directories(iso8583_parser PUBLIC include)
target_compile_options(iso8583_parser PRIVATE -Wall -Wextra -Wpedantic -Wconversion)
find_package(Threads REQUIRED)
# Boost.System is header-only for modern Boost; avoid mandatory binary package.
add_executable(gateway src/main.cpp src/gateway.cpp src/session.cpp src/logger.cpp)
target_include_directories(gateway PRIVATE include)
target_compile_options(gateway PRIVATE -Wall -Wextra -Wpedantic -Wconversion)
target_compile_definitions(gateway PRIVATE BOOST_ERROR_CODE_HEADER_ONLY)
target_link_libraries(gateway PRIVATE iso8583_parser Threads::Threads)
include(CTest)
if(BUILD_TESTING)
  add_executable(test_parser tests/test_parser.cpp)
  target_link_libraries(test_parser PRIVATE iso8583_parser)
  add_test(NAME parser_complete COMMAND test_parser)
  add_executable(test_compose tests/test_compose.cpp)
  target_link_libraries(test_compose PRIVATE iso8583_parser)
  add_test(NAME composer_complete COMMAND test_compose)
endif()

# Completed Day 4 persistence layer, preserved unchanged for Day 5.
find_package(SQLite3 REQUIRED)
add_library(database STATIC src/database.cpp)
target_compile_features(database PUBLIC cxx_std_17)
target_include_directories(database PUBLIC include)
target_link_libraries(database PUBLIC SQLite::SQLite3)
target_link_libraries(gateway PRIVATE database)

if(BUILD_TESTING)
  add_executable(test_database_wrapper tests/test_database_wrapper.cpp)
  target_link_libraries(test_database_wrapper PRIVATE database)
  foreach(case connection bound rollback commit moves reject_tail)
    add_test(NAME sqlite_${case} COMMAND test_database_wrapper ${case})
  endforeach()

  find_package(Python3 COMPONENTS Interpreter REQUIRED)
  add_test(NAME proxy_tcp_integration
    COMMAND ${Python3_EXECUTABLE}
      ${CMAKE_CURRENT_SOURCE_DIR}/tests/test_gateway_integration.py
      --gateway $<TARGET_FILE:gateway>)
  foreach(case authorized declined pending network reversal parallel)
    add_test(NAME persistence_${case}
      COMMAND ${Python3_EXECUTABLE}
        ${CMAKE_CURRENT_SOURCE_DIR}/tests/public/test_persistence.py
        --gateway $<TARGET_FILE:gateway> --case ${case})
  endforeach()
endif()
