#include "iso8583_parser.hpp"
#include <cassert>
#include <string>

using namespace payment_gateway;

int main() {
    Iso8583Parser codec;
    ParsedMessage message{};
    message.mti = "0200";
    message.present[3] = true;
    message.fields[3] = "000000";
    message.present[11] = true;
    message.fields[11] = "123456";
    message.present[39] = true;
    message.fields[39] = "00";
    message.present[42] = true;
    message.fields[42] = "MERCHANT0000001";
    message.present[123] = true;
    message.fields[123] = "511344101000000";
    message.present[124] = true;
    message.fields[124] = "ABC";

    auto wire = codec.compose(message);
    assert(wire.substr(0, 4) == "0200");
    assert(wire.find("0003ABC") != std::string::npos); // LLLLVAR
    auto parsed = codec.parse(wire);
    for (unsigned de : {3U, 11U, 39U, 42U, 123U, 124U}) {
        assert(parsed.present[de]);
        assert(parsed.fields[de] == message.fields[de]);
    }
    assert(codec.compose(parsed) == wire);

    message.fields[42] = "short";
    bool bad_length = false;
    try { (void)codec.compose(message); }
    catch (const ComposeError&) { bad_length = true; }
    assert(bad_length);

    message.fields[42] = "MERCHANT0000001";
    message.present[70] = true;
    message.fields[70] = "000";
    bool unsupported = false;
    try { (void)codec.compose(message); }
    catch (const ComposeError&) { unsupported = true; }
    assert(unsupported);
}
