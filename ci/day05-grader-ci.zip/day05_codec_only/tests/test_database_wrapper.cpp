// Instructor tests of the supplied RAII SQLite wrapper contract.
// Run through scripts/grade_day04.py, not in the student test directory.
#include "database.hpp"
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>

using namespace payment_gateway;
static void ensure(bool v, const char* desc) {
    if (!v) throw std::runtime_error(desc);
}
template<class F> static void must_throw(F f, const char* desc) {
    try { f(); } catch (const DatabaseError&) { return; }
    throw std::runtime_error(desc);
}
int main(int argc, char** argv) {
    const std::string which = argc>1 ? argv[1] : "";
    try {
        Database db(":memory:");
        db.execute_trusted("CREATE TABLE trial(id INTEGER PRIMARY KEY, name TEXT, amount INTEGER)");
        if(which=="connection") {
            ensure(db.changes()==0, "changes failed");
        } else if(which=="bound") {
            auto st=db.prepare("INSERT INTO trial(name,amount) VALUES(:name,:amount)");
            st.bind(":name", std::string_view("S' OR 1=1 --"));
            st.bind(":amount", std::int64_t{450});
            ensure(!st.step(), "INSERT expected SQLITE_DONE");
            ensure(db.changes()==1, "changes should equal 1");
            auto query=db.prepare("SELECT name,amount FROM trial WHERE amount=:amount");
            query.bind(":amount", std::int64_t{450});
            ensure(query.step(), "SELECT should return row");
            ensure(query.column_text(0)=="S' OR 1=1 --", "SQL injection was not data");
            ensure(query.column_int64(1)==450, "integer bind mismatch");
            ensure(!query.step(), "second step should return SQLITE_DONE");
        } else if(which=="rollback") {
            {
                auto tx=db.begin_transaction();
                auto st=db.prepare("INSERT INTO trial(name,amount) VALUES(:n,:a)");
                st.bind(":n",std::string_view("TEST"));
                st.bind(":a",std::int64_t{123});
                st.step();
                // Deliberate no commit: destructor must rollback.
            }
            auto query=db.prepare("SELECT count(*) FROM trial");
            ensure(query.step() && query.column_int64(0)==0, "RAII rollback failed");
        } else if(which=="commit") {
            {
                auto tx=db.begin_transaction();
                auto st=db.prepare("INSERT INTO trial(name,amount) VALUES(:n,:a)");
                st.bind(":n",std::string_view("TEST"));
                st.bind(":a",std::int64_t{123});
                st.step();
                tx.commit();
            }
            auto query=db.prepare("SELECT count(*) FROM trial");
            ensure(query.step() && query.column_int64(0)==1, "COMMIT failed");
        } else if(which=="moves") {
            auto first=db.prepare("INSERT INTO trial(name,amount) VALUES(:n,:a)");
            auto second=db.prepare("SELECT count(*) FROM trial");
            second=std::move(first); // must finalize old statement first
            second.bind(":n",std::string_view("X"));
            second.bind(":a",std::int64_t{2});
            ensure(!second.step(), "move-assign corrupt statement");
            auto tx=db.begin_transaction();
            auto moved=std::move(tx);
            moved.rollback();
        } else if(which=="reject_tail") {
            must_throw([&]{ (void)db.prepare("SELECT 1; DROP TABLE trial"); },
                       "prepare() accepted trailing SQL");
            auto query=db.prepare("SELECT count(*) FROM trial");
            ensure(query.step(),"table disappeared");
            must_throw([&]{ auto s=db.prepare("SELECT :value"); s.bind(":unknown",std::int64_t{1}); },
                       "unknown named placeholder accepted");
        } else {
            std::cerr<<"unknown test case\n";
            return 2;
        }
        std::cout<<"PASS "<<which<<'\n';
        return 0;
    } catch(const std::exception& error) {
        std::cerr<<"FAIL "<<which<<": "<<error.what()<<'\n';
        return 1;
    }
}
